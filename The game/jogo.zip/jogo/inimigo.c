#include "inimigo.h"

// ============================================
// INIT
// ============================================
void initPedinte(Pedinte* p, int x, int y, int w, int h) {
    p->pos = (SDL_Rect){x, y, w, h};
    p->frameRect = (SDL_Rect){0, 0, 210, 180};
    p->dir = ESQUERDA;
    p->estado = INIMIGO_PARADO;

    p->ultimoFrame = 0;
    p->frameAtual = 0;
    p->intervaloFrame = 300;

    p->distanciaVisao = 400;
    p->limiteEsq = x - 150;
    p->limiteDir = x + 150;

    p->ativo = 1;
    p->yBase = y;

    p->atrito = 0.8f;
    p->velDano = 0;

    p->sofrendoDano = 0;   // <-- corrigido
    p->vida = 10;
    p->morto = 0;
}

// ============================================
// UPDATE
// ============================================
void updatePedinte(Pedinte* p, SDL_Rect playerRect, Uint32 agora) {

	if(p->morto) return;
	
    // ===============================
    // ANIMAÇÃO DE DANO TEM PRIORIDADE
    // ===============================
    if (p->estado == INIMIGO_DANO) {

        // knockback
        p->pos.x += p->velDano;

        // atrito
        if (p->velDano > 0) {
            p->velDano -= p->atrito;
            if (p->velDano < 0) p->velDano = 0;
        } else {
            p->velDano += p->atrito;
            if (p->velDano > 0) p->velDano = 0;
        }

        // animação 6 frames
        if (agora - p->ultimoFrame > p->intervaloFrame) {
            p->ultimoFrame = agora;
            p->frameAtual++;

            if (p->frameAtual >= 6) {
                p->sofrendoDano = 0;      // <-- corrigido
                p->estado = INIMIGO_ANDANDO;
                p->frameAtual = 0;
            }
        }

        int linha = (p->dir == DIREITA) ? 4 : 3;

        p->frameRect = (SDL_Rect){
            210 * p->frameAtual,
            180 * linha,
            210, 180
        };

        return; // <-- impede qualquer outra ação
    }

    // ==========================================================
    // Lógica normal
    // ==========================================================

    float distancia = fabs((playerRect.x + playerRect.w/2) - (p->pos.x + p->pos.w/2));

    switch (p->estado) {
        case INIMIGO_PARADO:
            if (distancia < p->distanciaVisao) p->estado = INIMIGO_INICIANDO;
            break;

        case INIMIGO_INICIANDO:
            break;

        case INIMIGO_ANDANDO:
            if (distancia > p->distanciaVisao + 100)
                p->estado = INIMIGO_PATRULHANDO;
            break;

        case INIMIGO_PATRULHANDO:
            if (distancia < p->distanciaVisao)
                p->estado = INIMIGO_ANDANDO;
            break;
    }

    // ======================
    // LEVANTAR (linha 0)
    // ======================
    if (p->estado == INIMIGO_INICIANDO) {

        if (agora - p->ultimoFrame > p->intervaloFrame) {
            p->ultimoFrame = agora;

            if (p->frameAtual < 5)
                p->frameAtual++;
            else {
                p->estado = INIMIGO_ANDANDO;
                p->frameAtual = 0;
            }
        }

        p->frameRect = (SDL_Rect){
            210 * p->frameAtual,
            0,
            210, 180
        };
    }

    // ======================
    // ANDANDO (linha 1 ou 2)
    // ======================
    if (p->estado == INIMIGO_ANDANDO) {

        p->dir = (playerRect.x < p->pos.x) ? ESQUERDA : DIREITA;

        p->pos.x += (p->dir == DIREITA) ? 2 : -2;

        if (agora - p->ultimoFrame > p->intervaloFrame) {
            p->ultimoFrame = agora;
            p->frameAtual++;
            if (p->frameAtual > 6) p->frameAtual = 0;
        }

        int linha = (p->dir == DIREITA) ? 2 : 1;

        p->frameRect = (SDL_Rect){
            210 * p->frameAtual,
            175 * linha,
            210, 172
        };
    }

    // ========================
    // PATRULHA
    // ========================
    if (p->estado == INIMIGO_PATRULHANDO) {

        p->pos.x += (p->dir == DIREITA) ? 2 : -2;

        if (p->pos.x < p->limiteEsq) p->dir = DIREITA;
        if (p->pos.x + p->pos.w > p->limiteDir) p->dir = ESQUERDA;

        if (agora - p->ultimoFrame > p->intervaloFrame) {
            p->ultimoFrame = agora;
            p->frameAtual++;
            if (p->frameAtual > 6) p->frameAtual = 0;
        }

        int linha = (p->dir == DIREITA) ? 2 : 1;

        p->frameRect = (SDL_Rect){
            210 * p->frameAtual,
            175 * linha,
            210, 180
        };
    }

    // ======================
    // PARADO
    // ======================
    if (p->estado == INIMIGO_PARADO) {
        p->frameAtual = 0;
        p->frameRect = (SDL_Rect){0,0,210,180};
    }
    
    // ============================================
	// ANIMAÇÃO REVERSA (levantar de trás pra frente)
	// ============================================
	
	if (p->estado == INIMIGO_MORRENDO) {
		if (agora - p->ultimoFrame > p->intervaloFrame) {
	        p->ultimoFrame = agora;
	
	        if (p->frameAtual > 0) {
	            p->frameAtual--;       // toca ao contrário
	        } 
			else {
	            p->ativo = 0;          // ele nunca mais levanta
	            p->morto = 1;
	            
	             // mantém frame 0 morto
	            p->frameRect = (SDL_Rect){
	                0,      // frame 0
	                0,      // linha 0
	                210,180
	            };
	            return;
	        }
	    }
	
	    // linha 0 da spritesheet = levantar (normal)
	    p->frameRect = (SDL_Rect){
	        210 * p->frameAtual,
	        0,              // linha 0
	        210, 180
	    };
	
	    return;
	}
}

// Função de dano + knockback + animação

void pedinteTomarDano(Pedinte* p, int direcaoHit) {
	
	if(p->morto) return;
	if (p->estado == INIMIGO_MORRENDO) return;  // <-- BLOQUEIA DANO DURANTE MORTE

    p->estado = INIMIGO_DANO;
    p->sofrendoDano = 1;      // <-- corrigido
    p->frameAtual = 0;
    p->ultimoFrame = 0;
    p->intervaloFrame = 80;

    // Direção da animação
    p->dir = (direcaoHit > 0) ? DIREITA : ESQUERDA;

    // Knockback
    p->velDano = (direcaoHit > 0) ? 10 : -10;

    // Vida
    p->vida--;
    if (p->vida <= 0) {
	    p->estado = INIMIGO_MORRENDO;
	    p->frameAtual = 5;        // levantar reverso começa no último frame
	    p->ultimoFrame = SDL_GetTicks();
	    p->intervaloFrame = 150;  // ajuste se quiser mais lento
	    p->sofrendoDano = 0;
	    p->velDano = 0;
	    return; // sai da função porque já está morto
	}
}

// RENDER

void renderPedinte(SDL_Renderer* ren, SDL_Texture* tex, Pedinte* p, SDL_Rect camera) {
	
	int esquerdaTela = camera.x;
	int direitaTela  = camera.x + camera.w;
	
	if (p->pos.x + p->pos.w < esquerdaTela || p->pos.x > direitaTela) {
	    p->ativo = 0;
	    return;
	}
	
    SDL_Rect dest = p->pos;
    dest.x -= camera.x;
	

    SDL_RenderCopy(ren, tex, &p->frameRect, &dest);
}


// BOSS

//  INIT

void initBoss(Boss* b,int x, int y, int w, int h, int yFinal){
    b->pos = (SDL_Rect){x,y,w,h};
    
    b->frameRect = (SDL_Rect){0,0,200,260};
	b->distanciaVisao = 600;
	b->distanciaAtaque = 250;
	
    b->dir = ESQUERDA;
    b->velQueda = 12;
	b->yFinal = yFinal;

    b->ultimoFrame = 0;
    b->frameAtual = 0;
    b->intervaloFrame = 300;

    b->ativo = 1;
    // ⭐ ESSENCIAL — estava faltando e causava todo o bug
    b->estado = INIMIGO_INICIANDO;
}

void updateBoss(Boss* p, SDL_Rect playerRect, Uint32 agora) {

    float distancia = fabs((playerRect.x + playerRect.w/2) - (p->pos.x + p->pos.w/2));

    switch (p->estado) {

        // --------------------------------------------------
        // SPAWN (queda inicial)
        // --------------------------------------------------
        case INIMIGO_INICIANDO:
            p->pos.y += p->velQueda;

            if (p->pos.y >= p->yFinal) {
                p->pos.y = p->yFinal;
                p->estado = INIMIGO_PARADO;
            }

            // animação de spawn
            if (agora - p->ultimoFrame > p->intervaloFrame) {
                p->ultimoFrame = agora;
                p->frameAtual = (p->frameAtual + 1) % 4;
                p->frameRect.x = p->frameAtual * p->frameRect.w;
            }
            break;

        // --------------------------------------------------
        // PARADO
        // --------------------------------------------------
        case INIMIGO_PARADO:

            p->frameAtual = 0;
            p->frameRect = (SDL_Rect){0,0,200,260};

            if (distancia < p->distanciaAtaque) {
                p->estado = INIMIGO_TELEPORTANDO;
                break;
            }

            if (distancia < p->distanciaVisao) {
                p->estado = INIMIGO_ANDANDO;
                p->ultimoFrame = agora;
            }
            break;

        // --------------------------------------------------
        // ANDANDO
        // --------------------------------------------------
        case INIMIGO_ANDANDO:

            // Se estiver perto o suficiente para atacar → teleporta
            if (distancia < p->distanciaAtaque) {
                p->estado = INIMIGO_TELEPORTANDO;
                break;
            }

            p->dir = (playerRect.x < p->pos.x) ? ESQUERDA : DIREITA;
            p->pos.x += (p->dir == DIREITA) ? 2 : -2;

            if (agora - p->ultimoFrame > p->intervaloFrame) {
                p->ultimoFrame = agora;
                p->frameAtual = (p->frameAtual + 1) % 6;
            }

            p->frameRect = (SDL_Rect){
                200 * p->frameAtual,
                260 * ((p->dir == DIREITA) ? 2 : 1),
                200, 260
            };

            break;

        // --------------------------------------------------
        // TELETRANSPORTE (inicia ataque)
        // --------------------------------------------------
        case INIMIGO_TELEPORTANDO:

            // (Opcional: animação de sumir)

            // Boss se move para cima do player
            p->pos.x = playerRect.x + playerRect.w/2 - p->pos.w/2;
            p->pos.y = -300; // topo da tela

            p->estado = INIMIGO_CAINDO;
            break;

        // --------------------------------------------------
        // QUEDA DO ATAQUE
        // --------------------------------------------------
        case INIMIGO_CAINDO:

            p->pos.y += p->velQueda * 1.5; // queda mais rápida que o spawn

            if (p->pos.y >= p->yFinal) {
                p->pos.y = p->yFinal;

                // Volta ao estado parado após atingir o solo
                p->estado = INIMIGO_PARADO;
            }

            // Animação de queda (reutilizando a mesma do spawn)
            if (agora - p->ultimoFrame > p->intervaloFrame) {
                p->ultimoFrame = agora;
                p->frameAtual = (p->frameAtual + 1) % 4;
                p->frameRect.x = p->frameAtual * p->frameRect.w;
            }

            break;
    }
}


void renderBoss(SDL_Renderer* ren, SDL_Texture* tex, Boss* b, SDL_Rect camera) {	
    SDL_Rect dest = b->pos;
    dest.x -= camera.x;
	

    SDL_RenderCopy(ren, tex, &b->frameRect, &dest);
}