#ifndef DIRECAO_H
#define DIRECAO_H

enum Direcao{ ESQUERDA = -1, DIREITA = 1};

#endif