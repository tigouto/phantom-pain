#ifndef PLAYER_H
#define PLAYER_H

#include <SDL2/SDL.h>
#include "cenario.h"

#define RECUO_PEDINTE 100


typedef struct{
	SDL_Rect pos;
	SDL_Rect framePernasRect;
	SDL_Rect frameTroncoRect;
	enum Direcao dir;
	int vely;
	int gravidade;
	int noChao;
	int movendo;
	int virando;
	int frameVirada;
	int frameID;
	int frameIE;
	Uint32 ultimoFrameTroca;
	int intervaloFrame;
	int sofrendoDano;
	float velDano;
	Uint32 tempoKnockback;
	
	//ataque
	int atacando;
	SDL_Rect frameFoiceRect;
	SDL_Rect hitboxFoice;
	Uint32 tempoAtaque;
	Uint32 intervaloEntreAtaques;
	int frameAtaqueFoice;
	int frameAtaquePernas;
	int frameAtaqueTronco;
	Uint32 ultimoFrameAtaque;
	int intervaloFrameAtaque;
	int totalFramesAtaqueFoice;
	int totalFramesAtaquePernas;
	int totalFramesAtaqueTronco;
	int dano;
	int frameDano;
	int linhaDano;
	int totalFramesDano;
	Uint32 ultimoFrameDano;
	Uint32 intervaloFrameDano;

    
	//pulo
	int pulando;
	int puloInicial;
	float tempoPulo;
	int framePulo;
	Uint32 ultimoFramePulo;
	int intervaloFramePulo;
	int totalFramesPulo;
} Player;

void initPlayer(Player* p, SDL_Renderer* ren, int x, int y, int w, int h);
void updatePlayer(Player* p, const Uint8* keys, Uint32 agora, SDL_Rect chaoR,hudVida* vida, Cenario* cenarios, int atual, SDL_Rect* camera, SDL_Renderer* ren, int w,Boss* b);
void ImpedirPassar(Player* player, SDL_Rect barreira);
void playerTomarDano(Player* p, int direcao, Uint32 agora);
void renderPlayer(Player* p, SDL_Renderer* ren, SDL_Texture* sprites, SDL_Texture* spritesCorpo, SDL_Texture* spritesFoice, SDL_Rect camera);

#endif
