#ifndef PLAYER_H
#define PLAYER_H

#include <SDL2/SDL.h>
#include "cenario.h"

#define RECUO_PEDINTE 100


typedef struct{
	SDL_Rect pos;
	SDL_Rect frameRect;
	enum Direcao dir;
	int vely;
	int gravidade;
	int noChao;
	int movendo;
	int virando;
	int frameVirada;
	int frameID;
	int frameIE;
	Uint32 ultimoFrameTroca;
	int intervaloFrame;
	
	//ataque
	int atacando;
	SDL_Rect hitboxPlayer;
	Uint32 tempoAtaque;
	Uint32 intervaloEntreAtaques;
	int frameAtaque;
	Uint32 ultimoFrameAtaque;
	int intervaloFrameAtaque;
	int totalFramesAtaque;
	int dano;
    
	//pulo
	int pulando;
	int puloInicial;
	float tempoPulo;
	int framePulo;
	Uint32 ultimoFramePulo;
	int intervaloFramePulo;
	int totalFramesPulo;
} Player;

void initPlayer(Player* p, SDL_Renderer* ren, int x, int y, int w, int h);
void updatePlayer(Player* p, const Uint8* keys, Uint32 agora, SDL_Rect chaoR,hudVida* vida, Cenario* cenarios, int atual, SDL_Rect* camera, SDL_Renderer* ren);
void renderPlayer(Player* p, SDL_Renderer* ren, SDL_Texture* sprites, SDL_Rect camera);

#endif