#ifndef INIMIGO_H 
#define INIMIGO_H

#include <SDL2/SDL.h>
#include "direcao.h"

//-----------------Enums------------------

enum EstadoInimigo { 
    INIMIGO_PARADO, 
    INIMIGO_LEVANTANDO, 
    INIMIGO_ANDANDO, 
    INIMIGO_PATRULHANDO,
    INIMIGO_DANO,
    INIMIGO_MORRENDO, // << NOVO ESTADO
};

//---------------Struct---------------------------

typedef struct {
    SDL_Rect pos;        // posição e tamanho no mundo
    SDL_Rect frameRect;  // região da spritesheet atual
    enum Direcao dir;
    enum EstadoInimigo estado;

    Uint32 ultimoFrame;
    int frameAtual;
    int intervaloFrame;

    int distanciaVisao;
    int limiteEsq, limiteDir;
    
    int vida;
    int morto;
    int ativo;
    int yBase;

    // -------------------- DANO ----------------------
    int sofrendoDano;     // 1 quando tomou golpe
    float velDano;        // velocidade de recuo
    float atrito;         // desaceleração
    int frameDano;        // frame atual da animação de dano
    Uint32 ultimoFrameDano;
    int intervaloFrameDano;
    // -------------------------------------------------

} Pedinte;

//funções
void initPedinte(Pedinte* p, int x, int y, int w, int h);
void updatePedinte(Pedinte* p, SDL_Rect playerRect, Uint32 agora);
void renderPedinte(SDL_Renderer* ren, SDL_Texture* tex, Pedinte* p, SDL_Rect camera);
void pedinteTomarDano(Pedinte* p, int direcaoHit);   // <-- ADICIONAR AQUI


#endif

