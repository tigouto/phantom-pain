#ifndef CENARIO_H
#define CENARIO_H

#include <SDL2/SDL.h>
#include "pedinte.h"

#define MAX_PARALAX 8
#define MAX_ELEMENTOS 32
#define MAX_CENARIOS 8
#define MAX_PEDINTES 16

typedef struct {
    SDL_Texture* tex;
    float fator;
    int posY;
} Paralax;

typedef struct {
    SDL_Texture* tex;
    SDL_Rect pos;
} Elemento;

typedef struct{
	SDL_Texture* tex;
	SDL_Rect pos;
	int ativado;
	
	// Controle da animação
    int frameAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
    float tempoFrame;      
    float timer;          
} Checkpoint;

typedef struct {
    SDL_Texture* tex;
    SDL_Rect pos;
    int ativado;
    
    int frameAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
    int interagindo;    // 1 = se o player estiver próximo/interagindo
} Acampamento;

typedef enum {
    TIPO_ELEMENTO_CHECKPOINT,
    TIPO_ELEMENTO_ACAMPAMENTO
} TipoElemento;

typedef struct {
    TipoElemento tipo;
    union {
        Checkpoint checkpoint;
        Acampamento acampamento;
    };
} ElementoCenario;

typedef struct {
    SDL_Texture* fundo;
    Paralax paralax[MAX_PARALAX];
    int numParalax;

    Elemento atras[MAX_ELEMENTOS];
    int numAtras;

    Elemento frente[MAX_ELEMENTOS];
    int numFrente;
    
    Pedinte pedintes[MAX_PEDINTES];
    int numPedintes;
    
    ElementoCenario elementos[MAX_ELEMENTOS];
	int numElementos;

    int posX;       
    int largura;  
    int altura;     
} Cenario;

//funções

void initCenario(Cenario* c);
void addParalax(Cenario* c, SDL_Texture* tex, float fator, int posY);
void addAtras(Cenario* c, SDL_Texture* tex, SDL_Rect pos);
void addFrente(Cenario* c, SDL_Texture* tex, SDL_Rect pos);
void addPedinte(Cenario* c, int x, int y, int w, int h);
void addCheckpointElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos, int numFrames, int larguraFrame, int alturaFrame, float tempoFrame);
void addAcampamentoElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos, int numFrames, int larguraFrame, int alturaFrame);
void desenharCenario(SDL_Renderer* ren, Cenario* c, SDL_Rect camera, int screenW, int screenH, int w, int h);
void desenharParalax(SDL_Renderer* ren, SDL_Texture* tex, float fatorParalax, int cameraX, int posY, int screenW,int w,int h);
void desenharFrente(SDL_Renderer* ren, Cenario* c, SDL_Rect camera);
void fade_out_in(SDL_Renderer* ren, int screenW, int screenH, int fadeOut);
void updateCheckpoint(Checkpoint* cp, SDL_Rect player, float deltaTime);
void renderCheckpoint(SDL_Renderer* ren, Checkpoint* cp, SDL_Rect camera);
void updateAcampamento(Acampamento* ac, SDL_Rect player);
void renderAcampamento(SDL_Renderer* ren, Acampamento* ac, SDL_Rect camera);
void updateElementos(Cenario* c, SDL_Rect player, const Uint8* keys, float deltaTime, int* vidas);
void renderElementos(SDL_Renderer* ren, Cenario* c, SDL_Rect camera);

#endif