#ifndef CENARIO_H
#define CENARIO_H

#include <SDL2/SDL.h>
#include "pedinte.h"


#define MAX_PARALAX 8
#define MAX_ELEMENTOS 32
#define MAX_CENARIOS 8
#define MAX_PEDINTES 16
#define TEMPO_INVULNERAVEL 1000 // ms

typedef struct {
    SDL_Texture* tex;
    float fator;
    int posY;
} Paralax;

typedef struct {
    SDL_Texture* tex;
    SDL_Rect pos;
} Elemento;



typedef struct{
	SDL_Texture* tex;
	SDL_Rect pos;
	int ativado;
	
	// Controle da animação
    int frameAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
    float tempoFrame;      
    float timer;          
} Checkpoint;

typedef struct {
    SDL_Texture* tex;
    SDL_Rect pos;
    int ativado;
    
    int frameAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
    int interagindo;    // 1 = se o player estiver próximo/interagindo
} Acampamento;

typedef struct {
    SDL_Texture* tex;
    SDL_Rect pos;
    
    int frameAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
    int interagindo;    // 1 = se o player estiver próximo/interagindo
} Mesa;

typedef struct{
	SDL_Texture* tex;
	SDL_Rect src;
	SDL_Rect pos;
	int ativado;
	
	// Controle da animação
    int frameAtual;
    int linhaAtual;
    int numFrames;
    int larguraFrame;
    int alturaFrame;
	int ultimoFrame;
	int intervaloFrame;   
} Dialogo;

typedef enum {
    TIPO_ELEMENTO_CHECKPOINT,
    TIPO_ELEMENTO_ACAMPAMENTO,
    TIPO_ELEMENTO_MESA,
    TIPO_ELEMENTO_DIALOGO
} TipoElemento;

typedef struct {
    TipoElemento tipo;
    union {
        Checkpoint checkpoint;
        Acampamento acampamento;
        Mesa mesa;
        Dialogo dialogo;
    };
} ElementoCenario;

typedef struct {
    SDL_Texture* fundo;
    Paralax paralax[MAX_PARALAX];
    int numParalax;

    Elemento atras[MAX_ELEMENTOS];
    int numAtras;

    Elemento frente[MAX_ELEMENTOS];
    int numFrente;
    
    Pedinte pedintes[MAX_PEDINTES];
    int numPedintes;
    
    ElementoCenario elementos[MAX_ELEMENTOS];
	int numElementos;

    int posX;       
    int largura;  
    int altura;     
} Cenario;

typedef struct {
	SDL_Rect vidaRect;
    int vidas;                  // quantas flores ativas
    int florAnimando;           // -1 se nenhuma
    int frame;                  // frame da flor morrendo
    Uint32 ultimoFrame;         // controle de tempo
    int totalFrames;            // quantos frames tem a animação
    int intervalo;              // ms entre frames
    int invulneravel;
    Uint32 tempoInvulneravel;
} hudVida;

//funções

void initCenario(Cenario* c);
void addParalax(Cenario* c, SDL_Texture* tex, float fator, int posY);
void addAtras(Cenario* c, SDL_Texture* tex, SDL_Rect pos);
void addFrente(Cenario* c, SDL_Texture* tex, SDL_Rect pos);
void addPedinte(Cenario* c, int x, int y, int w, int h);
void addCheckpointElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos, int numFrames, int larguraFrame, int alturaFrame, float tempoFrame);
void addAcampamentoElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos, int numFrames, int larguraFrame, int alturaFrame);
void addMesaElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos, int numFrames, int larguraFrame, int alturaFrame);
void addDialogoElemento(Cenario* c, SDL_Texture* tex, SDL_Rect pos);
void desenharCenario(SDL_Renderer* ren, Cenario* c, SDL_Rect camera, int screenW, int screenH, int w, int h);
void desenharParalax(SDL_Renderer* ren, SDL_Texture* tex, float fatorParalax, int cameraX, int posY, int screenW,int w,int h);
void desenharFrente(SDL_Renderer* ren, Cenario* c, SDL_Rect camera);
void fade_out_in(SDL_Renderer* ren, int screenW, int screenH, int fadeOut);
void updateCheckpoint(Checkpoint* cp, SDL_Rect player, float deltaTime);
void renderCheckpoint(SDL_Renderer* ren, Checkpoint* cp, SDL_Rect camera);
void updateAcampamento(Acampamento* ac, SDL_Rect player);
void renderAcampamento(SDL_Renderer* ren, Acampamento* ac, SDL_Rect camera);
void renderMesa(SDL_Renderer* ren, Mesa* m, SDL_Rect camera);
void renderDialogosAcima(SDL_Renderer* ren, Cenario* c, SDL_Rect camera);
void updateElementos(Cenario* c, SDL_Rect player, const Uint8* keys, float deltaTime, int* vidas, int* atual, int* dentro, int w);
void renderElementos(SDL_Renderer* ren, Cenario* c, SDL_Rect camera);
void perderFlor(hudVida* hud, Uint32 agora);
void updateFlor(hudVida* vida, Uint32 agora);
void renderHudFlores(SDL_Renderer* ren, SDL_Texture* texFlor, hudVida hud, int w, SDL_Rect vidaRect);

#endif
