#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <assert.h>

int main (int argc, char* args[])
{
    /* INICIALIZAÇÃO */
    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(IMG_INIT_PNG);
    SDL_Window* win = SDL_CreateWindow("Game v0.1",
                         SDL_WINDOWPOS_UNDEFINED,
                         SDL_WINDOWPOS_UNDEFINED,
                         0, 0,
                         SDL_WINDOW_FULLSCREEN_DESKTOP);
	SDL_Renderer* ren = SDL_CreateRenderer(win, -1, 0);
	
	SDL_Texture* fundo      = IMG_LoadTexture(ren, "bg-menu.png");
	SDL_Texture* logo       = IMG_LoadTexture(ren, "pp-logo.png");
    SDL_Texture* novo       = IMG_LoadTexture(ren, "novo-j.png");
    SDL_Texture* continuar  = IMG_LoadTexture(ren, "continuar.png");
    SDL_Texture* sair       = IMG_LoadTexture(ren, "sair.png");
    
    assert(fundo && logo && novo && continuar && sair);
    
    int w, h;
    SDL_GetWindowSize(win, &w, &h);

    SDL_EventState(SDL_MOUSEMOTION, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONUP, SDL_IGNORE);
    
    // --- LOGO ---
    int logoW = 640, logoH = 290;
    float escalaLogo = 1.2f; // logo maior
    int logoFinalW = (int)(logoW * escalaLogo);
    int logoFinalH = (int)(logoH * escalaLogo);

    int logoY = 40; 
    SDL_Rect titulo = { (w - logoFinalW)/2, logoY, logoFinalW, logoFinalH };

    // --- BOTÕES ---
    int btnSrcW = 315, btnSrcH = 35;
    float escalaBtn = 1.8f; 
    int btnFinalW = (int)(btnSrcW * escalaBtn);
    int btnFinalH = (int)(btnSrcH * escalaBtn);

    int espacamento = 40; 
    int startY = logoY + logoFinalH + 40;

    SDL_Rect novoJ      = { (w - btnFinalW)/2, startY,                       btnFinalW, btnFinalH };
    SDL_Rect continuarJ = { (w - btnFinalW)/2, startY + btnFinalH + espacamento, btnFinalW, btnFinalH };
    SDL_Rect sairJ      = { (w - btnFinalW)/2, startY + 2*(btnFinalH + espacamento), btnFinalW, btnFinalH };

    SDL_Rect n = {315,0,315,35}; 
    SDL_Rect c = {0,0,315,35};
    SDL_Rect s = {0,0,315,35};
  
    int espera = 16;
    int selecionadoN = 1;
	int selecionadoC = 0;
	int selecionadoS = 0;    
    
    int rodando = 1;
    while(rodando && !SDL_QuitRequested()){
    	
    	SDL_RenderCopy(ren, fundo ,NULL, NULL);
        SDL_RenderCopy(ren, logo ,NULL, &titulo);
        SDL_RenderCopy(ren, novo ,&n, &novoJ);
        SDL_RenderCopy(ren, continuar ,&c, &continuarJ);
        SDL_RenderCopy(ren, sair ,&s, &sairJ);
        
        SDL_RenderPresent(ren);
        
        SDL_Event evt;
        int isevt = SDL_WaitEventTimeout(&evt, espera);
        if (isevt && evt.type == SDL_QUIT) break;

        // TECLADO
		if (evt.type == SDL_KEYDOWN){
			switch(evt.key.keysym.scancode) {
            	case SDL_SCANCODE_DOWN:
            	case SDL_SCANCODE_UP:
                    if (selecionadoN == 1) {
                        n = (SDL_Rect){0,0,315,35};
                        s = (SDL_Rect){315,0,315,35};
                        selecionadoN = 0;
                        selecionadoS = 1;
                    } 
				    else if (selecionadoS == 1) {
                        s = (SDL_Rect){0,0,315,35};
                        n = (SDL_Rect){315,0,315,35};
                        selecionadoN = 1;
                        selecionadoS = 0;
                    }
                break;
                
                case SDL_SCANCODE_RETURN:
                case SDL_SCANCODE_Z:
                    if(selecionadoS == 1){
                        rodando = 0; 
                    }
                break;
        	}
		}
	}

    SDL_DestroyTexture(sair);
    SDL_DestroyTexture(continuar);
    SDL_DestroyTexture(novo);
    SDL_DestroyTexture(logo);
    SDL_DestroyTexture(fundo);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
}

